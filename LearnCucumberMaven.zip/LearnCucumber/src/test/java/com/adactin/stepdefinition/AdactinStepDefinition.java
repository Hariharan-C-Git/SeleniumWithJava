package com.adactin.stepdefinition;

import java.io.IOException;

import com.adactin.execution.AdactinExecution;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class AdactinStepDefinition {

	public AdactinExecution exec = new AdactinExecution();

	@Given("Website should be opened")
	public void website_should_be_opened() throws IOException {
		exec.adactin();

	}

	@When("login with username and password")
	public void login_with_username_and_password() throws IOException {
		exec.credentials();

	}

	@When("Click the login button")
	public void click_the_login_button() {
		exec.clicklog();

	}

	@Then("Login should be successfully")
	public void login_should_be_successfully() {
		System.out.println("Login Successfully");

	}

	
	@When("Enter input for search Hotel")
	public void enter_input_for_search_hotel() throws IOException {
		exec.selectLocation();
		exec.selectHotels();
		exec.roomType();
		exec.noOfRooms();
		exec.adult();
		exec.child();
	}

	@When("Click Search button")
	public void click_search_button() {
		exec.clickSearch();

	}

	@Then("Hotels should be displayed")
	public void hotels_should_be_displayed() {
		System.out.println("Search results successfully displayed");
	}

}
