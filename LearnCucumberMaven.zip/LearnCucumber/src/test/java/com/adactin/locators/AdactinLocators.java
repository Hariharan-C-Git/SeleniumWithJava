package com.adactin.locators;

import org.openqa.selenium.By;

public class AdactinLocators {

	public static By findusername() {
		return By.id("username");

	}

	public static By findpassword() {
		return By.id("password");

	}

	public static By clickLogin() {
		return By.id("login");

	}

	public static By selectLocation() {
		return By.id("location");
	}

	public static By selectHotel() {
		return By.id("hotels");
	}

	public static By selectRoomType() {
		return By.id("room_type");
	}

	public static By noOfRooms() {
		return By.id("room_nos");
	}

	public static By adultPerRoom() {
		return By.id("adult_room");
	}

	public static By childPerRoom() {
		return By.id("child_room");
	}

	public static By submitButton() {
		return By.id("Submit");
	}

	public static By clickRadioButton() {
		return By.id("radiobutton_0");
	}

	public static By firstName() {
		return By.id("first_name");
	}

	public static By lastName() {
		return By.id("last_name");
	}

	public static By billingAddress() {
		return By.id("address");
	}

	public static By creditCard() {
		return By.id("cc_num");
	}

	public static By creditCardType() {
		return By.id("cc_type");
	}

	public static By expiryMonth() {

		return By.id("cc_exp_month");
	}

	public static By expiryYear() {
		return By.id("cc_exp_year");
	}

	public static By creditCardCVV() {
		return By.id("cc_cvv");
	}

	public static By ClickBookNow() {
		return By.id("book_now");
	}

	public static By orderNumber() {
		
		return By.id("order_no");
	}
}
