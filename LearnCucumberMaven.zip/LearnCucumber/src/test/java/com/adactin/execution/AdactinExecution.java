package com.adactin.execution;

import java.io.IOException;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.html5.AddApplicationCache;

import com.adactin.base.AdactinBase;
import com.adactin.locators.AdactinLocators;

public class AdactinExecution {

	public static AdactinBase base = new AdactinBase();

	public void adactin() throws IOException {

		base.browserLaunch();
		// base.getURL("http://adactinhotelapp.com/index.php");
		base.getURL(base.readValueFromExcel(0, 1, "Sheet1"));
	}

	public void credentials() throws IOException {
		WebElement findElementId = base.findElementId(AdactinLocators.findusername());
		base.sendkeys(findElementId, base.readValueFromExcel(1, 1, "Sheet1"));
		WebElement findElementId2 = base.findElementId(AdactinLocators.findpassword());
		base.sendkeys(findElementId2, base.readValueFromExcel(2, 1, "Sheet1"));

	}

	public void clicklog() {
		base.click(base.findElementId(AdactinLocators.clickLogin()));
		//base.implicitWait();
	}

	public void selectLocation() throws IOException {
		base.implicitWait();
		base.explicitWait(base.findElementId(AdactinLocators.selectLocation()));
		WebElement findElementId = base.findElementId(AdactinLocators.selectLocation());
		base.selectByVisibleTexxt(findElementId, base.readValueFromExcel(3, 1, "Sheet1"));
		//base.selectByVisibleText(findElementId, base.valueFromPropertyFile("Location"));
		//base.selectByIndex(base.findElementId(AdactinLocators.selectLocation()), 2);
	}

	public void selectHotels() throws IOException {
		WebElement findElementId = base.findElementId(AdactinLocators.selectHotel());
		//base.selectByVisibleText(findElementId, base.readValueFromExcel(4, 1, "Sheet1"));
		base.selectByVisibleTexxt(findElementId, base.valueFromPropertyFile("Hotels"));
	
	}

	public void roomType() throws IOException {

		WebElement findElementId = base.findElementId(AdactinLocators.selectRoomType());
		//base.selectByVisibleText(findElementId, base.readValueFromExcel(5, 1, "Sheet1"));
		base.selectByVisibleTexxt(findElementId, base.valueFromPropertyFile("Room Type"));
	}

	public void noOfRooms() throws IOException {
		WebElement findElementId = base.findElementId(AdactinLocators.noOfRooms());
		//base.selectByVisibleText(findElementId, base.readValueFromExcel(6, 1, "Sheet1"));
		base.selectByVisibleTexxt(findElementId, base.valueFromPropertyFile("Number of Rooms"));
	}

	public void adult() throws IOException {
		WebElement findElementId = base.findElementId(AdactinLocators.adultPerRoom());
		//base.selectByVisibleText(findElementId, base.readValueFromExcel(7, 1, "Sheet1"));
		base.selectByVisibleTexxt(findElementId, base.valueFromPropertyFile("Adults per Room"));
	}

	public void child() throws IOException {
		WebElement findElementId = base.findElementId(AdactinLocators.childPerRoom());
		//base.selectByVisibleText(findElementId, base.readValueFromExcel(8, 1, "Sheet1"));
		base.selectByVisibleTexxt(findElementId, base.valueFromPropertyFile("Children per Room"));

	}

	public void clickSearch() {
		base.click(base.findElementId(AdactinLocators.submitButton()));
		//base.implicitWait();
	}

}
