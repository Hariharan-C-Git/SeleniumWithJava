package com.adactin.base;

import java.awt.event.ActionEvent;
import java.beans.PropertyChangeListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import javax.swing.Action;
import javax.swing.plaf.FileChooserUI;

import org.apache.commons.io.FileUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class AdactinBase {

	public static WebDriver driver;

	public void browserLaunch() {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\2697\\eclipse-workspace\\mavenproject\\TestData\\chromedrivernew.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();

	}

	public void implicitWait() {
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	}

	public void getURL(String url) {

		driver.get(url);
	}

	public WebElement findElementId(By id) {
		return driver.findElement(id);

	}

	public WebElement findElementXpath(String xpath) {
		return driver.findElement(By.xpath(xpath));
	}

	public void sendkeys(WebElement find, String keyContent) {

		find.sendKeys(keyContent);

	}

	public void click(WebElement clickElement) {
		clickElement.click();
	}

	public void selectByIndex(WebElement indexElement, int indexValue) {

		Select sindex = new Select(indexElement);
		sindex.selectByIndex(indexValue);

	}

	public void selectByValue(WebElement valueElement, String selectValue) {

		Select svalue = new Select(valueElement);
		svalue.selectByValue(selectValue);
	}

	public void selectByVisibleTexxt(WebElement visibleElement, String selectVisibleText) {

		Select visibletxt = new Select(visibleElement);
		visibletxt.selectByVisibleText(selectVisibleText);
	}

	public void takeScreenShot() throws IOException {

		TakesScreenshot ts = (TakesScreenshot) driver;
		File screenshotAs = ts.getScreenshotAs(OutputType.FILE);
		String timestamp = new SimpleDateFormat("yyyy_MM_dd__hh_mm_ss").format(new Date());
		File des = new File("C:\\Users\\2697\\eclipse-workspace\\LearnCucumber\\ScreenShot" + timestamp + ".png");
		FileUtils.copyFile(screenshotAs, des);

	}

	public String getAttributeValue(WebElement getAtbute) {
		return getAtbute.getAttribute("value");
	}

	public String valueFromPropertyFile(String valuefromprop) throws IOException {
		FileReader fileread = new FileReader(
				"C:\\Users\\2697\\eclipse-workspace\\LearnCucumber\\ScreenShot\\Adactin.properties");
		Properties prop = new Properties();
		prop.load(fileread);
		return prop.getProperty(valuefromprop);
		

	}
	
	public void explicitWait(WebElement waiit) {
		
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(waiit));
		
	}

	public String readValueFromExcel(int row, int cell, String sheeet) throws IOException {
		String Value = null;
		File file = new File("C:\\Users\\2697\\eclipse-workspace\\LearnCucumber\\ScreenShot\\Adactin.xlsx");
		FileInputStream input = new FileInputStream(file);
		Workbook wb = new XSSFWorkbook(input);
		Sheet sheet = wb.getSheet(sheeet);
		Row row2 = sheet.getRow(row);
		Cell cell2 = row2.getCell(cell);
		int cellType = cell2.getCellType();
		if (cellType == 1) {
			Value = cell2.getStringCellValue();

		}
		if (cellType == 0) {

			if (DateUtil.isCellDateFormatted(cell2)) {

				SimpleDateFormat date = new SimpleDateFormat("DD-MM-YYYY");
				Value = date.format(cell2.getDateCellValue());
			} else {

				double numericCellValue = cell2.getNumericCellValue();
				long numvalue = (long) numericCellValue;
				Value = String.valueOf(numvalue);

			}

		}
		return Value;

	}
}
