package com.login;

import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class LoginPage {

	WebDriver driver;

	@Given("Google URL should be opened")
	public void google_url_should_be_opened() {

		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\2697\\eclipse-workspace\\mavenproject\\TestData\\chromedrivernew.exe");
		driver = new ChromeDriver();
		driver.get("https://www.google.com");
		driver.manage().window().maximize();
	}

	@When("Type the text {string}")
	public void type_the_text(String string) {
		driver.findElement(By.name("q")).sendKeys(string);

	}

	@When("Hit the search key")
	public void hit_the_search_key() {
		driver.findElement(By.name("q")).sendKeys(Keys.ENTER);

	}

	@Then("results should be opened")
	public void results_should_be_opened() {

		boolean displayed = driver.findElement(By.partialLinkText("sachin")).isDisplayed();
		if (displayed) {

			System.out.println("Results Displayed");
		}

	}

}
